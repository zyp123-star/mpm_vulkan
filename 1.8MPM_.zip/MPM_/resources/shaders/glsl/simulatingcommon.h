struct Particle {
    vec3 pos;
    
    vec3 vel;    

    vec3 C1;         
    vec3 C2;
    vec3 C3;
    float density;
};


struct Cell {
    int vx;
    int vy;
    int vz;
    int mass;
};

struct Fs {
    vec3 fs1;       // �����ݶ� mat3 fsfs => ������ => vec3 fsfs1 fsfs2 fsfs3
    vec3 fs2;
    vec3 fs3;
};


layout(binding = 0) buffer readonly PosIn { Particle particlesIn[]; }; 
layout(binding = 1) buffer PosOut { Particle particlesOut[]; };        
layout(binding = 2) buffer cells { Cell grid[]; };                      
layout(binding = 3) buffer deformationGradientIn { Fs FsIn[]; };       
layout(binding = 4) buffer deformationGradientOut { Fs FsOut[]; };      

layout(binding = 5) uniform UBO {
    float deltaT;           // ʱ�䲽��
    float particleCount;    // ��������
    float elastic_lambda;   // ����ģ����Ӧ��Lam��������
    float elastic_mu;       // ����ģ����Ӧ��Lam��������
};

layout(binding=6) uniform UniformBoxInfoObject{
    vec2 clampX;
    vec2 clampY;
    vec2 clampZ; 

    vec2 clampX_still;
    vec2 clampY_still;
    vec2 clampZ_still; 
};

layout(binding = 7) uniform sampler2D depthTexture;

// 各种常量
const float fixed_point_multiplier = 1e7;
const vec3 init_box_size = vec3(52.0, 52.0, 52.0);
const float stiffness = 3.0f;
const float rest_density = 4.0f;
const float dynamic_viscosity = 0.1f;
const float dt = 0.05f;
const float sphereRadius = 15.0f;
const float k = 3.0;
const float wall_stiffness = 1.0;


const int GRID_RESOLUTION = 52;
//const float dt = 0.0005;
const float box_long = 1.0;
const float GRAVITY = 9.8;
const float INV_GRID_RESOLUTION = 1.0 / GRID_RESOLUTION;
const float DX = box_long / GRID_RESOLUTION;
// INV_DX = 32;
const float INV_DX = 1.0 / DX;
const float apicDinverse = 4.0 / (DX * DX);
//const float particle_volume = 0.0197;
//const float particle_mass = 0.0197;
const float particle_volume = 0.0000016;
const float particle_mass = 0.0000016;
const float flip_ratio = 0.95;
const float dt_particle_volume = dt * particle_volume;
const vec3 GRAVITY_vec3 = vec3(0.0, -GRAVITY, 0.0);
const vec3 dt_gravity = dt * GRAVITY_vec3;

// ����ת��
mat3 transpose_mat3(mat3 m) {
    return transpose(m);
}

mat3 outerProduct_mat3(vec3 a, vec3 b){
    mat3 M = outerProduct(a, b);
    return M;
}

// ��������ʽ��3x3��
float determinant_mat3(mat3 m) {
    return determinant(m);
}

// �������棨3x3��
mat3 inverse_mat3(mat3 m) {
    return inverse(m);
}

// ����˷�
mat3 multiply_mat3(mat3 a, mat3 b) {
    return a * b;
}

// �������
mat3 subtract_mat3(mat3 a, mat3 b) {
    return a - b;
}

// ������������
mat3 scalar_mult_mat3(mat3 m, float s) {
    return m * s;
}

mat3 add_mat3(mat3 a, mat3 b) {
    return a + b;
}

// 3ά����ת1ά����
int index_3d_to_1d(ivec3 idx) {
    return idx.x * GRID_RESOLUTION * GRID_RESOLUTION + idx.y * GRID_RESOLUTION + idx.z;
}

// 1ά����ת3ά����
ivec3 index_1d_to_3d(int idx) {
    int z = idx % GRID_RESOLUTION;
    int y = (idx / GRID_RESOLUTION) % GRID_RESOLUTION;
    int x = idx / (GRID_RESOLUTION * GRID_RESOLUTION);
    return ivec3(x, y, z);
}

// �������
mat3 outer_product(vec3 a, vec3 b) {
    return mat3(
        a.x * b,
        a.y * b,
        a.z * b
    );
}

int sgn(float val) {
    return (val > 0.0) ? 1 : ((val < 0.0) ? -1 : 0);
}

float N(float u) {
    float uabs = abs(u);
    if (uabs < 0.5) {
        return 0.75 - uabs * uabs;
    }
    else if (uabs < 1.5) {
        return 0.5 * (1.5 - uabs) * (1.5 - uabs);
    }
    else {
        return 0;
    }
}

float dNdu(float u) {
    float uabs = abs(u);
    if (uabs < 0.5) {
        return (-2 * u);
    }
    else if (uabs < 1.5) {
        return (u - 1.5 * sgn(u));
    }
    else {
        return 0;
    }
}


float wip(float xp, float yp, float zp, float xi, float yi, float zi, float one_over_h) {
    return N((xp - xi) * one_over_h) *
        N((yp - yi) * one_over_h) *
        N((zp - zi) * one_over_h);
}

vec3 grad_wip(float xp, float yp, float zp, float xi, float yi, float zi, float one_over_h) {
    return vec3(
        dNdu((xp - xi) * one_over_h) * N((yp - yi) * one_over_h) * N((zp - zi) * one_over_h) * one_over_h,
        dNdu((yp - yi) * one_over_h) * N((xp - xi) * one_over_h) * N((zp - zi) * one_over_h) * one_over_h,
        dNdu((zp - zi) * one_over_h) * N((xp - xi) * one_over_h) * N((yp - yi) * one_over_h) * one_over_h
    );
}

mat3 NeoHookeanPiola(mat3 Fe) {
    return elastic_mu * (Fe - inverse(transpose(Fe))) + elastic_lambda * log(determinant(Fe)) * inverse(transpose(Fe));
}
// 将浮点数编码为定点整数
int encodeFixedPoint(float floating_point) {
    return int(floating_point * fixed_point_multiplier);
}
// 将定点整数解码为浮点数
float decodeFixedPoint(int fixed_point) {
    return float(fixed_point) / fixed_point_multiplier;
}



/*结构体创建、gpu buffer创建，分配大小和偏移量，创建总的buffer。uniform buffer创建，创建并更新值。两种buffer的资源绑定，set是池子，binding。计算着色器写完后编译，并执行，找到管仿真的那部分simulation，然后还要更新绑定命令？*/