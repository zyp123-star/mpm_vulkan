﻿#include"renderer.h"
#include"renderer_types.h"
#include"glm/gtc/matrix_transform.hpp"

#include<iostream>
#include<exception>
#include<chrono>
#include<string>
#include<algorithm>
#include<random>
#undef APIENTRY
#define NOMINMAX

#define PI 3.1415926f



int main(int argc, char** argv) {

    try {
        // 初始化
        // float radius = 0.008;
        float boxSize = 52.0f;
        glm::vec3 boxMin(0.0f), boxMax(boxSize);
        glm::vec3 center = (boxMin + boxMax) * 0.5f; // (26,26,26)

        float radius = 0.5f;
        float fov = glm::radians(90.0f);
        float aspect = 1.0f;
        float distance = (boxSize / 2.0f) / tan(fov / 2.0f); // 26

        Renderer renderer(800, 800, true);

        UniformRenderingObject renderingobj{};
        renderingobj.model = glm::mat4(1.0f);

        // 相机沿 X 轴负方向看向盒子中心
        glm::vec3 cameraPos(center.x - distance, center.y, center.z);
        glm::vec3 target = center;
        glm::vec3 up(0, 1, 0);
        renderingobj.view = glm::lookAt(cameraPos, target, up);

        // 投影矩阵
        renderingobj.projection = glm::perspective(fov, aspect, 0.1f, distance + boxSize);
        renderingobj.projection[1][1] *= -1; // Vulkan 修正
        renderingobj.inv_projection = glm::inverse(renderingobj.projection);

        renderingobj.zNear = 0.1f;
        renderingobj.zFar = distance + boxSize;
        renderingobj.aspect = aspect;
        renderingobj.fovy = fov;
        renderingobj.particleRadius = radius;
        renderer.SetRenderingObj(renderingobj);



        UniformSimulatingObject simulatingobj{};
        simulatingobj.deltaT = DT;
        simulatingobj.particleCount = NUM_PARTICLE;
        simulatingobj.elastic_lambda = ELASTIC_LAMBDA;
        simulatingobj.elastic_mu = ELASTIC_MU;
        renderer.SetSimulatingObj(simulatingobj);
        // 盒子空间信息
        UniformBoxInfoObject boxinfoobj{};
        boxinfoobj.clampX = glm::vec2{ 0.0, 15.0 };
        boxinfoobj.clampY = glm::vec2{ 0.0, 52.0 };
        boxinfoobj.clampZ = glm::vec2{ 0.0, 52.0 };
        boxinfoobj.clampX_still = glm::vec2{ 0.0, 52.0 };
        boxinfoobj.clampY_still = glm::vec2{ 0.0, 52.0 };
        boxinfoobj.clampZ_still = glm::vec2{ 0.0, 52.0 };
        renderer.SetBoxinfoObj(boxinfoobj);

       
        // particles & fs & grid  => initialize
        std::vector<Particle> ParticleBuffer(NUM_PARTICLE);
        std::vector<Fs> FsBuffer(NUM_PARTICLE);
        std::vector<Cell> GridBuffer(NUM_CELLS);


        glm::vec3 initBoxSize = { 52.0f, 52.0f, 52.0f };
        float dx = 0.5f;
        glm::vec3 center_now = initBoxSize / 2.0f;
        //glm::vec3 beg(center_now.x, 5.0f, 5.0f);
        glm::vec3 beg(5.0f, 5.0f, 5.0f);
        float vScale = 0.6f;
        std::uniform_real_distribution<float> jitter_dis(-dx * 0.05f, dx * 0.05f); // 微扰动
        std::default_random_engine gen(std::random_device{}());
        int numParticles = 0;


        for (int i = 0; i < 32 ; i++) {
            for (int j = 0; j < 32 ; j++) {
                for (int k = 0; k < 32 ; k++) {
                    float jitter = jitter_dis(gen);

                    glm::vec3 pos = beg + glm::vec3(i * dx + jitter, j * dx + jitter, k * dx + jitter);
                    glm::vec3 vDir = glm::normalize(center_now - pos);

                    ParticleBuffer[numParticles] = {
                        .pos = pos,
                        .vel = vDir * vScale,// .vel = glm::vec3(0.0f)也能达成同样的效果
                        .C1 = glm::vec3(0.0f),
                        .C2 = glm::vec3(0.0f),
                        .C3 = glm::vec3(0.0f),
                        .density = 0.0f
                    };

                    numParticles++;
                }
            }
        }


    /*
        // 随机数
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<float> jitter_dis(0.0f, 2.0f);  // 随机扰动范围
        // 粒子数据初始化
        // 粒子间距
        const float spacing = 0.55f;
        // 模拟盒子尺寸（对应 initBoxSize，例如 64x64x64）
        glm::ivec3 initBoxSize = glm::ivec3(52, 52, 52);
        int numParticles = 0;

        // y方向: 填充到高度的80%
        // x方向: [3, initBoxSize.x - 4]
        // z方向: [3, initBoxSize.z / 2]
        for (float j = 3.0f; j < initBoxSize.y * 0.8f && numParticles < NUM_PARTICLE; j += spacing) {
            for (float i = 3.0f; i < initBoxSize.x - 4 && numParticles < NUM_PARTICLE; i += spacing) {
                for (float k = 3.0f; k < initBoxSize.z / 2.0f && numParticles < NUM_PARTICLE; k += spacing) {

                    // 添加随机扰动
                    float jitter = jitter_dis(gen);

                    

                    ParticleBuffer[numParticles] = {
                        .pos = glm::vec3(i + jitter, j + jitter, k + jitter),
                        
                        .vel = {0.0f, 0.0f, 0.0f},
                        .C1 = {0.0f, 0.0f, 0.0f},
                        .C2 = {0.0f, 0.0f, 0.0f},
                        .C3 = {0.0f, 0.0f, 0.0f},
                        .density = 0.0f
                    };


                    FsBuffer[numParticles] = {
                    .fs1 = glm::vec3(1.0, 0.0, 0.0),
                    .fs2 = glm::vec3(0.0, 1.0, 0.0),
                    .fs3 = glm::vec3(0.0, 0.0, 1.0)
                    };

                    numParticles++;
                }
            }
        }
        */
/*
        // =============================
// 粒子规则初始化（32768 粒子）
// =============================
        int nx = 64; // x 方向更宽
        int ny = 16; // y 方向更薄
        int nz = 32; // z 方向适中

        float spacing = 0.004; // 自动按盒子比例算间距
        glm::vec3 startPos(0.2f, 0.2f, 0.2f); // 起始偏移量，使粒子位于盒子中部偏下

        int index = 0;
        for (int ix = 0; ix < nx; ++ix) {
            for (int iy = 0; iy < ny; ++iy) {
                for (int iz = 0; iz < nz; ++iz) {
                    if (index >= NUM_PARTICLE) break;

                    glm::vec3 pos = startPos + glm::vec3(
                        ix * spacing,
                        iy * spacing,
                        iz * spacing
                    );

                    ParticleBuffer[index] = {
                        .pos = pos,
                        .vel = {0.0f, 0.0f, 0.0f},
                        .pic = {0.0f, 0.0f, 0.0f},
                        .flip = {0.0f, 0.0f, 0.0f},
                        .C1 = {0.0f, 0.0f, 0.0f},
                        .C2 = {0.0f, 0.0f, 0.0f},
                        .C3 = {0.0f, 0.0f, 0.0f},
                        .mass = 0.0000016f,
                        .volume_0 = 0.0000016f
                    };

                    FsBuffer[index] = {
                        .fs1 = glm::vec3(1.0f, 0.0f, 0.0f),
                        .fs2 = glm::vec3(0.0f, 1.0f, 0.0f),
                        .fs3 = glm::vec3(0.0f, 0.0f, 1.0f)
                    };

                    ++index;
                }
            }
        }
        */
        // 网格信息
        for (int i = 0; i < NUM_CELLS; ++i) {
        
                    GridBuffer[i] = {
                        .vx = 0,
                        .vy = 0,
                        .vz = 0,
                        .mass = 0
                    };
        }


        // 设置
        renderer.SetParticles(ParticleBuffer);
        renderer.SetFs(FsBuffer);
        renderer.SetCell(GridBuffer);
        
        float accumulated_time = 0.0f;  
        renderer.Init();                
        auto now = std::chrono::high_resolution_clock::now(); 

        // **新增：记录鼠标按下的时间**
        static std::chrono::high_resolution_clock::time_point lastPressTime;
        static float pressDuration = 0.0f;  // 记录鼠标按下持续时间
        const float changeSpeed = 0.5f;  // 每秒变化的值

        // 监听鼠标事件
        bool isLeftPressed_mouse = false;

        for (;;) {
            auto last = now;    
            now = std::chrono::high_resolution_clock::now();   
            float deltatime = std::chrono::duration<float, std::chrono::seconds::period>(now - last).count(); 

            //float dt = std::clamp(deltatime, 1 / 360.0f, 1 / 60.0f); 
            float dt = DT;  // 固定时间间隔
            accumulated_time += dt; 

            simulatingobj.deltaT = dt;  
            renderer.SetSimulatingObj(simulatingobj);   

            // **新增：记录鼠标按下状态，防止每一帧都增加过多**
            static bool isLeftPressed = false;  // 左键按下状态
            static bool isRightPressed = false; // 右键按下状态

            if (glfwGetKey(renderer.GetWindow(), GLFW_KEY_UP) == GLFW_PRESS) {
                if (!isLeftPressed) {
                    // 上箭头键首次按下时，重置持续时间
                    lastPressTime = std::chrono::high_resolution_clock::now();
                    isLeftPressed = true;
                }

                // 计算按下的持续时间
                pressDuration = std::chrono::duration<float>(std::chrono::high_resolution_clock::now() - lastPressTime).count();

                // 平滑增量随按下时间增加
                float increment = changeSpeed * pressDuration;  // 按下的时间越长，增量越大
                boxinfoobj.clampX.y += increment;  // 上箭头按下时增加
                if (boxinfoobj.clampX.y > 22.0f)
                    boxinfoobj.clampX.y = 22.0f;
            }
            else {
                isLeftPressed = false;  // 上箭头松开时，重置按下状态
            }

            if (glfwGetKey(renderer.GetWindow(), GLFW_KEY_DOWN) == GLFW_PRESS) {
                if (!isRightPressed) {
                    // 下箭头键首次按下时，重置持续时间
                    lastPressTime = std::chrono::high_resolution_clock::now();
                    isRightPressed = true;
                }

                // 计算按下的持续时间
                pressDuration = std::chrono::duration<float>(std::chrono::high_resolution_clock::now() - lastPressTime).count();

                // 平滑增量随按下时间增加
                float increment = changeSpeed * pressDuration;  // 按下的时间越长，增量越大
                boxinfoobj.clampX.y -= increment;  // 下箭头按下时减少
                if (boxinfoobj.clampX.y < 10.0f)
                    boxinfoobj.clampX.y = 10.0f;
            }
            else {
                isRightPressed = false;  // 下箭头松开时，重置按下状态
            }
            renderer.SetBoxinfoObj(boxinfoobj);  
            /*
            if (glfwGetMouseButton(renderer.GetWindow(), GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS) {
                if (!isLeftPressed_mouse) {
                    glm::vec3 newPos(5.0f, 5.0f, 5.0f);
                    float cubeSize = 2.0f;
                    float vScale = 1.0f; // 初速度缩放

                    // 新增粒子形成 10x10x10 小立方体
                    for (int i = 0; i < 10; i++) {
                        for (int j = 0; j < 10; j++) {
                            for (int k = 0; k < 10; k++) {
                                glm::vec3 pos = newPos + glm::vec3(i * cubeSize, j * cubeSize, k * cubeSize);
                                glm::vec3 vDir = glm::normalize(center_now - pos);

                                ParticleBuffer.push_back({
                                    .pos = pos,
                                    .vel = vDir * vScale,
                                    .C1 = glm::vec3(0.0f),
                                    .C2 = glm::vec3(0.0f),
                                    .C3 = glm::vec3(0.0f),
                                    .density = 0.0f
                                    });
                            }
                        }
                    }

                    // 更新 GPU buffer
                    renderer.UpdateParticleBuffer(ParticleBuffer);

                    isLeftPressed_mouse = true;
                }
            }
            else {
                isLeftPressed_mouse = false;
            }*/

            renderer.Simulate();    // 仿真

            auto result = renderer.TickWindow(deltatime);      

            if (result == TickWindowResult::EXIT) {
                break;
            }
            if (result != TickWindowResult::HIDE) {
                renderer.Draw();
            }
            // 打印 FPS
            printf("%f\n", 1 / deltatime);
        }
        renderer.Cleanup();
    }
    catch (std::runtime_error err) {
        std::cerr << err.what() << std::endl;
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;   
}