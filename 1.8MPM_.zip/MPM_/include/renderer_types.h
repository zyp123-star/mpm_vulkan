#ifndef RENDERER_TYPES_H
#define RENDERER_TYPES_H
#define GLFW_INCLUDE_VULKAN
#include"GLFW/glfw3.h"
#include"glm/glm.hpp"

#include<vector>
#include<array>
#include<optional>

//#define NUM_PARTICLE 262144
#define NUM_PARTICLE 32768
#define GRID_RESOLUTION 52
#define NUM_CELLS (GRID_RESOLUTION * GRID_RESOLUTION * GRID_RESOLUTION)
//#define ELASTIC_LAMBDA 1000.0f  
#define ELASTIC_LAMBDA 100.0f 
//#define ELASTIC_MU 0.0001f  
#define ELASTIC_MU 0.001f  
//#define DT 0.0002f
#define DT 0.05f

struct QueuefamliyIndices{
    std::optional<uint32_t> graphicNcompute;
    std::optional<uint32_t> present;
    bool IsCompleted(){
        return graphicNcompute.has_value()&&present.has_value();
    }
};
struct SurfaceDetails{
    VkSurfaceCapabilitiesKHR capabilities;
    std::vector<VkSurfaceFormatKHR> formats;
    std::vector<VkPresentModeKHR> presentmode;
    
};
enum class TickWindowResult{
    NONE,
    HIDE,
    EXIT,
};

/*struct Cell {
    alignas(16) glm::vec3 pos;
    alignas(16) glm::vec3 vel;   
    alignas(16) glm::vec3 force;
    alignas(16) glm::vec3 flip;
    alignas(4)  float mass;     
};*/

struct Cell {
    alignas(4) int vx;  // x �����ٶ�
    alignas(4) int vy;  // y �����ٶ�
    alignas(4) int vz;  // z �����ٶ�
    alignas(4) int mass; // ����
};

struct Fs {
    alignas(16)glm::vec3 fs1;
    alignas(16)glm::vec3 fs2;
    alignas(16)glm::vec3 fs3;
};

struct Particle {
    alignas(16) glm::vec3 pos;
    
    alignas(16) glm::vec3 vel;
    //alignas(16) glm::vec3 pic;
    //alignas(16) glm::vec3 flip;  
    alignas(16) glm::vec3 C1;
    alignas(16) glm::vec3 C2;
    alignas(16) glm::vec3 C3;
    float density;
    //alignas(4) float mass;      
    //alignas(4) float volume_0;   
    

    static VkVertexInputBindingDescription GetBinding(){
        VkVertexInputBindingDescription binding{};
        binding.binding = 0;
        binding.inputRate = VK_VERTEX_INPUT_RATE_VERTEX;
        binding.stride = sizeof(Particle);
        return binding;
    } 
    static std::array<VkVertexInputAttributeDescription,1> GetAttributes(){
        std::array<VkVertexInputAttributeDescription,1> attributes;
        attributes[0].binding = 0;
        attributes[0].location = 0;
        attributes[0].format = VK_FORMAT_R32G32B32_SFLOAT;
        attributes[0].offset = offsetof(Particle,pos);
        return attributes;
    }
};

struct UniformRenderingObject{
    alignas(4) float zNear;
    alignas(4) float zFar;
    alignas(4) float fovy;
    alignas(4) float aspect;

    alignas(16) glm::mat4 model = glm::mat4(1.0f);
    alignas(16) glm::mat4 view = glm::mat4(1.0f);
    alignas(16) glm::mat4 projection = glm::mat4(1.0f);
    alignas(16) glm::mat4 inv_projection = glm::mat4(1.0f);
    
    alignas(4) float particleRadius;
};

struct UniformSimulatingObject{
    alignas(4) float deltaT;           
    alignas(4) float particleCount;    
    alignas(4) float elastic_lambda;   
    alignas(4) float elastic_mu;       
};

struct UniformBoxInfoObject{
    alignas(8) glm::vec2 clampX;
    alignas(8) glm::vec2 clampY;
    alignas(8) glm::vec2 clampZ; 

    alignas(8) glm::vec2 clampX_still;
    alignas(8) glm::vec2 clampY_still;
    alignas(8) glm::vec2 clampZ_still; 
};

struct UniformMouseInfoObject {
    alignas(8) glm::vec2 screenSize;
    alignas(8) glm::vec2 mouseCoord;
    alignas(8) glm::vec2 mouseVel;

    alignas(4) float mouseRadius;
   
};

#endif