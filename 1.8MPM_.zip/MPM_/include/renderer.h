#ifndef RENDER_H
#define RENDER_H
#define GLFW_INCLUDE_VULKAN
#define GLM_FORCE_DEPTH_ZERO_TO_ONE
#define GLM_FORCE_RADIANS
#include"GLFW/glfw3.h"
#include"glm/glm.hpp"
#include"renderer_types.h"
#include "camera.hpp"

#include<vector>
#include<array>
#include<optional>
#include<string>

class Renderer{
public:
    Renderer(uint32_t w,uint32_t h,bool validation = false);
    virtual ~Renderer();
public:
    TickWindowResult TickWindow(float DeltaTime);
    void Init();
    void Cleanup();
    void Updateinit(std::vector<Particle>& particles);
public:
    void Simulate();
    void BoxRender(uint32_t dstimage);
    void FluidsRender(uint32_t dstimage);
    void Draw();
    void UpdateParticleBuffer(std::vector<Particle>& particles);
public:
    void WaitIdle();
private:
    void CreateInstance();
    void CreateDebugMessenger();
    void CreateSurface();
    void PickPhysicalDevice();
    void CreateLogicalDevice();

    void CreateSupportObjects();
    void CleanupSupportObjects();
    void CreateCommandPool();

    void CreateParticleBuffer();
    void CreateGridBuffer();
    void CreateFsBuffer();

    void CreateUniformRenderingBuffer();
    void CreateUniformSimulatingBuffer();
    void CreateUniformBoxInfoBuffer();

    void CreateDepthResources();
    void CreateThickResources();
    void CreateDefaultTextureResources();
    void CreateBackgroundResources();

    void CreateSwapChain();
    void CleanupSwapChain();
    void RecreateSwapChain();

    void CreateDescriptorSetLayout();
    void CreateDescriptorPool();
    void CreateDescriptorSet();
    void UpdateDescriptorSet();

    void CreateRenderPass();
    void CreateGraphicPipelineLayout();
    void CreateGraphicPipeline();

    void CreateComputePipelineLayout();
    void CreateComputePipeline();

    void CreateFramebuffers();

    void RecordSimulatingCommandBuffers();
    void RecordFluidsRenderingCommandBuffers();
    void RecordBoxRenderingCommandBuffers();

    //void UpdateParticleBuffer(std::vector<Particle>& particles);


private:
    void GetRequestInstaceExts(std::vector<const char*>& exts);
    void GetRequestInstanceLayers(std::vector<const char*>& layers);
    void MakeMessengerInfo(VkDebugUtilsMessengerCreateInfoEXT& createinfo);
    QueuefamliyIndices GetPhysicalDeviceQueueFamilyIndices(VkPhysicalDevice pdevice);
    bool IsPhysicalDeviceSuitable(VkPhysicalDevice pdevice);
    void GetRequestDeviceExts(std::vector<const char*>& exts);
    void GetRequestDeviceFeature(VkPhysicalDeviceFeatures& features);
    SurfaceDetails GetSurfaceDetails();
    VkSurfaceFormatKHR ChooseSwapChainImageFormat(std::vector<VkSurfaceFormatKHR>& formats);
    VkPresentModeKHR ChooseSwapChainImagePresentMode(std::vector<VkPresentModeKHR>& presentmodes);
    VkExtent2D ChooseSwapChainImageExtents(VkSurfaceCapabilitiesKHR& capabilities);
    
    static VKAPI_ATTR VkBool32 VKAPI_CALL DebugCallback(VkDebugUtilsMessageSeverityFlagBitsEXT messageSeverity,VkDebugUtilsMessageTypeFlagsEXT messageTypes,
    const VkDebugUtilsMessengerCallbackDataEXT* pCallbackData,void* pUserData);
    static void  WindowResizeCallback(GLFWwindow* window,int width,int height);
    VkShaderModule MakeShaderModule(const char* filename);

    VkCommandBuffer CreateCommandBuffer();
    void SubmitCommandBuffer(VkCommandBuffer& cb,VkSubmitInfo submitinfom,VkFence fence,VkQueue queue);

    void CreateBuffer(VkBuffer& buffer,VkDeviceMemory& memory,VkDeviceSize size,VkBufferUsageFlags usage,VkMemoryPropertyFlags memproperties);
    uint32_t ChooseMemoryType(uint32_t typefilter,VkMemoryPropertyFlags properties);
    void CleanupBuffer(VkBuffer& buffer,VkDeviceMemory& memory,bool mapped);
    void CreateImage(VkImage &image, VkDeviceMemory &memory,VkExtent3D extent,VkFormat format, VkImageUsageFlags usage,VkSampleCountFlagBits samplecount);
    void ImageLayoutTransition(VkImage& image,VkImageLayout oldlayout,VkImageLayout newlayout,VkImageAspectFlags asepct);

private:
    VkImageView CreateImageView(VkImage image,VkFormat format,VkImageAspectFlags aspectMask);

    // �޸�����������Window & mouse
    static void MouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
    static void MouseMoveCallback(GLFWwindow* window, double xPos, double yPos);
    static void MouseScrollCallback(GLFWwindow* window, double xOffset, double yOffset);

    void MousePressed(GLFWwindow* window, int button, int action, int mods);
    void MouseMoved(GLFWwindow* window, double xPos, double yPos);
    void MouseScroll(GLFWwindow* window, double xOffset, double yOffset);

    bool middleMousePressed = false;
    bool rightMousePressed = false;

    double lastX = 0.0, lastY = 0.0;
    //float panSpeed = 0.005f;
    //float zoomSpeed = 0.1f;
    float panSpeed = 0.02f;
    float zoomSpeed = 2.0f;
    float rotateSpeed = 0.1f;

    glm::vec3 mousePos = glm::vec3(0.0f, 0.0f, 0.0f);
    uint32_t attract = 0;

    glm::vec3 cameraPos = glm::vec3(1.10f, 0.6f, 1.71f);
    glm::vec3 cameraTarget = glm::vec3(1.11f, 0.5f, 0.30f);
    glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

    glm::vec3 cameraPos_ = glm::vec3(1.10f, 1.04f, 1.61f);
    glm::vec3 cameraTarget_ = glm::vec3(1.11f, 0.84f, 0.30f);
    glm::vec3 cameraUp_ = glm::vec3(0.0f, 1.0f, 0.0f);

private:
    GLFWwindow* Window = nullptr;
    VkInstance Instance;
    VkDebugUtilsMessengerEXT Messenger;
    VkSurfaceKHR Surface;

    VkPhysicalDevice PDevice;
    VkDevice LDevice;
    VkQueue GraphicNComputeQueue;
    VkQueue PresentQueue;

    VkCommandPool CommandPool;
    VkSwapchainKHR SwapChain;
    VkFormat SwapChainImageFormat;
    VkExtent2D SwapChainImageExtent;
    std::vector<VkImage> SwapChainImages;
    std::vector<VkImageView> SwapChainImageViews;

    VkDescriptorPool DescriptorPool;

    VkRenderPass FluidGraphicRenderPass;
    VkDescriptorSetLayout FluidGraphicDescriptorSetLayout;
    VkDescriptorSet FluidGraphicDescriptorSet;
    VkPipelineLayout FluidGraphicPipelineLayout;
    VkPipeline FluidGraphicPipeline;

    VkRenderPass BoxGraphicRenderPass;
    VkDescriptorSetLayout BoxGraphicDescriptorSetLayout;
    VkDescriptorSet BoxGraphicDescriptorSet;
    VkPipelineLayout BoxGraphicPipelineLayout;
    VkPipeline BoxGraphicPipeline;
    // ����EulerParticle��EulerGrid
    VkDescriptorSetLayout SimulateDescriptorSetLayout;
    std::vector<VkDescriptorSet> SimulateDescriptorSet;
    VkPipelineLayout SimulatePipelineLayout;
    VkPipeline SimulatePipeline_ClearGrid;
    VkPipeline SimulatePipeline_ParticleToGrid;
    VkPipeline SimulatePipeline_UpdateGrid;
    VkPipeline SimulatePipeline_EulerParticle;
    //VkPipeline SimulatePipeline_EulerGrid;
    VkPipeline SimulatePipeline_GridToParticle;

    VkDescriptorSetLayout FilterDecsriptorSetLayout;
    VkDescriptorSet FilterDescriptorSet;
    VkPipelineLayout FilterPipelineLayout;
    VkPipeline FilterPipeline;

    VkDescriptorSetLayout PostprocessDescriptorSetLayout;
    std::vector<VkDescriptorSet> PostprocessDescriptorSets;
    VkPipelineLayout PostprocessPipelineLayout;
    VkPipeline PostprocessPipeline;

    VkFence DrawingFence;
    VkSemaphore ImageAvaliable;
    VkSemaphore FluidsRenderingFinish;
    VkSemaphore BoxRenderingFinish;
    VkSemaphore SimulatingFinish;

    VkBuffer UniformRenderingBuffer;
    VkDeviceMemory UniformRenderingBufferMemory;
    void* MappedRenderingBuffer;

    VkBuffer UniformSimulatingBuffer;
    VkDeviceMemory UniformSimulatingBufferMemory;
    void* MappedSimulatingBuffer;

    VkBuffer UniformBoxInfoBuffer;
    VkDeviceMemory UniformBoxInfoBufferMemory;
    void* MappedBoxInfoBuffer;

    VkImage ThickImage;
    VkDeviceMemory ThickImageMemory;
    VkImageView ThickImageView;
    VkSampler ThickImageSampler;

    VkImage DepthImage;
    VkDeviceMemory DepthImageMemory;
    VkImageView DepthImageView;

    VkImage CustomDepthImage;
    VkDeviceMemory CustomDepthImageMemory;
    VkImageView CustomDepthImageView;
    VkSampler CustomDepthImageSampler;

    VkImage FilteredDepthImage;
    VkDeviceMemory FilteredDepthImageMemory;
    VkImageView FilteredDepthImageView;
    VkSampler FilteredDepthImageSampler;

    VkImage DefaultTextureImage;
    VkDeviceMemory DefaultTextureImageMemory;
    VkImageView DefaultTextureImageView;
    VkSampler DefaultTextureImageSampler;

    VkImage BackgroundImage;
    VkDeviceMemory BackgroundImageMemory;
    VkImageView BackgroundImageView;
    VkSampler BackgroundImageSampler;

    VkFramebuffer FluidsFramebuffer;
    VkFramebuffer BoxFramebuffer;

    std::vector<VkBuffer> ParticleBuffers;
    std::vector<VkDeviceMemory> ParticleBufferMemory;

    VkBuffer BoxVertexBuffer;
    VkDeviceMemory BoxVertexBufferMemory;

    std::vector<VkBuffer> GridBuffers;
    std::vector<VkDeviceMemory> GridBufferMemory;

    std::vector<VkBuffer> FsBuffers;
    std::vector<VkDeviceMemory> FsBufferMemory;

    std::vector<VkCommandBuffer> SimulatingCommandBuffers;
    std::vector<VkCommandBuffer> FluidsRenderingCommandBuffers[2];
    VkCommandBuffer BoxRenderingCommandBuffer;
public:
    void SetRenderingObj(const UniformRenderingObject& robj);
    void SetSimulatingObj(const UniformSimulatingObject& sobj);
    void SetBoxinfoObj(const UniformBoxInfoObject& bobj);
    void SetParticles(const std::vector<Particle>& ps);
    void SetFs(const std::vector<Fs>& fss);
    void SetCell(const std::vector<Cell>& cell);

private:
    
    bool Initialized = false;
    uint32_t Width;
    uint32_t Height;
    std::vector<Particle> particles;
    std::vector<Cell> grids;
    std::vector<Fs> fs;

    UniformRenderingObject renderingobj{};
    UniformSimulatingObject simulatingobj{};
    UniformBoxInfoObject boxinfobj{};

    bool bEnableValidation = false;
    uint32_t CurrentFlight = 0;
    uint32_t MAXInFlightRendering = 2;

    uint32_t ONE_GROUP_INVOCATION_COUNT = 512;
    uint32_t WORK_GROUP_COUNT;
    uint32_t GRID_WORK_GROUP_COUNT; //����

    uint32_t MAX_NGBR_NUM = 128;
    bool bFramebufferResized = false;


public:
    GLFWwindow* GetWindow() const {
        return Window;
    }
    std::vector<Particle> GetParticlesFromGPU();
    std::vector<Cell> GetGridFromGPU();


};
#endif